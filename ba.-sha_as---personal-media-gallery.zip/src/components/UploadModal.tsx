import React, { useState, useRef } from 'react';
import {
  UploadCloud,
  FileImage,
  Film,
  CheckCircle2,
  AlertCircle,
  X,
  FileUp,
  Loader2,
} from 'lucide-react';
import type { MediaItem, UploadItem } from '../types';
import { uploadMediaItem } from '../lib/firebase';
import { formatBytes } from '../lib/formatters';

interface UploadModalProps {
  isOpen: boolean;
  onClose: () => void;
  onItemUploaded: (item: MediaItem) => void;
}

export const UploadModal: React.FC<UploadModalProps> = ({
  isOpen,
  onClose,
  onItemUploaded,
}) => {
  const [items, setItems] = useState<UploadItem[]>([]);
  const [isDragging, setIsDragging] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const handleFiles = (fileList: FileList | null) => {
    if (!fileList || fileList.length === 0) return;

    const newItems: UploadItem[] = Array.from(fileList).map((file) => {
      const isVideo = file.type.startsWith('video/');
      return {
        id: `upload-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
        file,
        name: file.name,
        size: file.size,
        type: isVideo ? 'video' : 'image',
        progress: 0,
        uploadedBytes: 0,
        status: 'pending',
      };
    });

    setItems((prev) => [...prev, ...newItems]);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    handleFiles(e.dataTransfer.files);
  };

  const removeItem = (id: string) => {
    setItems((prev) => prev.filter((i) => i.id !== id));
  };

  const startUploads = async () => {
    const pendingItems = items.filter((i) => i.status === 'pending');
    if (pendingItems.length === 0) return;

    setIsUploading(true);

    for (const item of pendingItems) {
      setItems((prev) =>
        prev.map((i) => (i.id === item.id ? { ...i, status: 'uploading' } : i))
      );

      try {
        const uploadedMedia = await uploadMediaItem(
          item.file,
          (progress, transferredBytes) => {
            setItems((prev) =>
              prev.map((i) =>
                i.id === item.id
                  ? { ...i, progress, uploadedBytes: transferredBytes }
                  : i
              )
            );
          }
        );

        setItems((prev) =>
          prev.map((i) =>
            i.id === item.id
              ? {
                  ...i,
                  status: 'completed',
                  progress: 100,
                  downloadUrl: uploadedMedia.downloadUrl,
                }
              : i
          )
        );

        onItemUploaded(uploadedMedia);
      } catch (err: any) {
        setItems((prev) =>
          prev.map((i) =>
            i.id === item.id
              ? {
                  ...i,
                  status: 'error',
                  error: err?.message || 'Upload failed',
                }
              : i
          )
        );
      }
    }

    setIsUploading(false);
  };

  const pendingCount = items.filter((i) => i.status === 'pending').length;
  const completedCount = items.filter((i) => i.status === 'completed').length;
  const totalBytes = items.reduce((acc, i) => acc + i.size, 0);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div
        className="w-full max-w-2xl bg-zinc-900 border border-zinc-800 rounded-2xl shadow-2xl flex flex-col max-h-[85vh] relative"
        role="dialog"
        aria-modal="true"
        aria-labelledby="upload-modal-title"
      >
        {/* Header */}
        <div className="p-6 border-b border-zinc-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center text-indigo-400">
              <FileUp className="w-5 h-5" />
            </div>
            <div>
              <h2 id="upload-modal-title" className="text-lg font-semibold text-zinc-100">
                Upload Original Media
              </h2>
              <p className="text-xs text-zinc-400">
                Original quality preserved byte-for-byte. Photos & videos up to 500+ MB supported.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            disabled={isUploading}
            className="text-zinc-400 hover:text-zinc-200 p-1.5 rounded-lg hover:bg-zinc-800 transition disabled:opacity-50"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content body */}
        <div className="p-6 overflow-y-auto space-y-5 flex-1">
          {/* Dropzone */}
          <div
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
            onClick={() => fileInputRef.current?.click()}
            className={`border-2 border-dashed rounded-2xl p-8 text-center cursor-pointer transition-all duration-200 ${
              isDragging
                ? 'border-indigo-500 bg-indigo-500/10'
                : 'border-zinc-800 hover:border-zinc-700 bg-zinc-950/40 hover:bg-zinc-950/60'
            }`}
          >
            <input
              ref={fileInputRef}
              type="file"
              multiple
              accept="image/*,video/*"
              className="hidden"
              onChange={(e) => handleFiles(e.target.files)}
            />
            <div className="w-12 h-12 rounded-2xl bg-zinc-900 border border-zinc-800 flex items-center justify-center text-indigo-400 mx-auto mb-3 shadow-lg">
              <UploadCloud className="w-6 h-6" />
            </div>
            <p className="text-sm font-medium text-zinc-200">
              Drag & drop photos or videos here, or <span className="text-indigo-400 underline underline-offset-2">browse</span>
            </p>
            <p className="text-xs text-zinc-500 mt-1">
              Supports JPEG, PNG, WEBP, MP4, MOV, WebM with zero transcoding
            </p>
          </div>

          {/* Queue List */}
          {items.length > 0 && (
            <div className="space-y-3">
              <div className="flex items-center justify-between text-xs text-zinc-400 px-1">
                <span>
                  {items.length} file{items.length > 1 ? 's' : ''} queued ({formatBytes(totalBytes)})
                </span>
                {completedCount > 0 && (
                  <span className="text-emerald-400 font-medium">
                    {completedCount} completed
                  </span>
                )}
              </div>

              <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
                {items.map((item) => (
                  <div
                    key={item.id}
                    className="p-3 bg-zinc-950/70 border border-zinc-800/80 rounded-xl space-y-2"
                  >
                    <div className="flex items-center justify-between gap-3">
                      <div className="flex items-center gap-2.5 min-w-0">
                        {item.type === 'video' ? (
                          <Film className="w-4 h-4 text-purple-400 shrink-0" />
                        ) : (
                          <FileImage className="w-4 h-4 text-indigo-400 shrink-0" />
                        )}
                        <span className="text-xs font-mono text-zinc-200 truncate">
                          {item.name}
                        </span>
                        <span className="text-[11px] text-zinc-500 shrink-0">
                          {formatBytes(item.size)}
                        </span>
                      </div>

                      <div className="flex items-center gap-2 shrink-0">
                        {item.status === 'completed' && (
                          <span className="flex items-center gap-1 text-[11px] text-emerald-400 font-medium">
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            Done
                          </span>
                        )}
                        {item.status === 'error' && (
                          <span className="flex items-center gap-1 text-[11px] text-rose-400 font-medium">
                            <AlertCircle className="w-3.5 h-3.5" />
                            Failed
                          </span>
                        )}
                        {item.status === 'uploading' && (
                          <span className="flex items-center gap-1 text-[11px] text-indigo-400 font-medium">
                            <Loader2 className="w-3.5 h-3.5 animate-spin" />
                            {item.progress}%
                          </span>
                        )}
                        {item.status === 'pending' && !isUploading && (
                          <button
                            onClick={() => removeItem(item.id)}
                            className="text-zinc-500 hover:text-zinc-300 p-0.5 rounded transition"
                          >
                            <X className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </div>

                    {/* Progress Bar */}
                    {item.status === 'uploading' && (
                      <div className="space-y-1">
                        <div className="w-full bg-zinc-800 rounded-full h-1.5 overflow-hidden">
                          <div
                            className="bg-indigo-500 h-full transition-all duration-150"
                            style={{ width: `${item.progress}%` }}
                          />
                        </div>
                        <div className="flex justify-between text-[10px] text-zinc-500 font-mono">
                          <span>{formatBytes(item.uploadedBytes)} transferred</span>
                          <span>{formatBytes(item.size)}</span>
                        </div>
                      </div>
                    )}

                    {item.error && (
                      <p className="text-[11px] text-rose-400 leading-tight">{item.error}</p>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-6 border-t border-zinc-800 flex items-center justify-between bg-zinc-900/50">
          <div className="text-xs text-zinc-500">
            {completedCount === items.length && items.length > 0
              ? 'All files successfully saved.'
              : 'Files upload directly into original storage.'}
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={onClose}
              disabled={isUploading}
              className="px-4 py-2 text-xs font-medium text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800 rounded-xl transition disabled:opacity-50"
            >
              {completedCount === items.length && items.length > 0 ? 'Close' : 'Cancel'}
            </button>
            {pendingCount > 0 && (
              <button
                onClick={startUploads}
                disabled={isUploading}
                className="flex items-center gap-2 px-5 py-2.5 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed text-white text-xs font-semibold rounded-xl shadow-lg shadow-indigo-600/20 transition active:scale-[0.98]"
              >
                {isUploading ? (
                  <>
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    <span>Uploading...</span>
                  </>
                ) : (
                  <>
                    <UploadCloud className="w-3.5 h-3.5" />
                    <span>Upload {pendingCount} {pendingCount === 1 ? 'file' : 'files'}</span>
                  </>
                )}
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
