import React from 'react';
import {
  FileImage,
  Film,
  FolderOpen,
  ArrowUpDown,
  Download,
  Trash2,
  X,
  Layers,
  Sparkles,
} from 'lucide-react';
import type { MediaItem, FilterCategory, SortOrder } from '../types';
import { MediaCard } from './MediaCard';
import { formatBytes } from '../lib/formatters';

interface GalleryProps {
  items: MediaItem[];
  isLoading: boolean;
  filter: FilterCategory;
  sortOrder: SortOrder;
  selectedIds: Set<string>;
  onFilterChange: (f: FilterCategory) => void;
  onSortChange: (s: SortOrder) => void;
  onItemClick: (item: MediaItem, index: number) => void;
  onSelectToggle: (item: MediaItem) => void;
  onSelectAll: () => void;
  onClearSelection: () => void;
  onDeleteRequest: (item: MediaItem) => void;
  onBulkDeleteRequest: () => void;
  onBulkDownloadRequest: () => void;
}

export const Gallery: React.FC<GalleryProps> = ({
  items,
  isLoading,
  filter,
  sortOrder,
  selectedIds,
  onFilterChange,
  onSortChange,
  onItemClick,
  onSelectToggle,
  onSelectAll,
  onClearSelection,
  onDeleteRequest,
  onBulkDeleteRequest,
  onBulkDownloadRequest,
}) => {
  const allCount = items.length;
  const photosCount = items.filter((i) => i.type === 'image').length;
  const videosCount = items.filter((i) => i.type === 'video').length;

  const filteredItems = items
    .filter((item) => {
      if (filter === 'image') return item.type === 'image';
      if (filter === 'video') return item.type === 'video';
      return true;
    })
    .sort((a, b) => {
      return sortOrder === 'newest'
        ? b.uploadDate - a.uploadDate
        : a.uploadDate - b.uploadDate;
    });

  const selectedItems = items.filter((i) => selectedIds.has(i.id));
  const selectedBytes = selectedItems.reduce((acc, i) => acc + i.size, 0);

  return (
    <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      {/* Filter and Control Bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4 pb-4 border-b border-zinc-800/80">
        {/* Filter Tabs */}
        <div className="flex items-center gap-1.5 p-1 bg-zinc-900/90 border border-zinc-800/90 rounded-xl overflow-x-auto">
          <button
            onClick={() => onFilterChange('all')}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-medium transition whitespace-nowrap ${
              filter === 'all'
                ? 'bg-zinc-800 text-white shadow-sm'
                : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800/50'
            }`}
          >
            <Layers className="w-3.5 h-3.5 text-zinc-400" />
            <span>All</span>
            <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-zinc-950/80 text-zinc-400 font-mono">
              {allCount}
            </span>
          </button>

          <button
            onClick={() => onFilterChange('image')}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-medium transition whitespace-nowrap ${
              filter === 'image'
                ? 'bg-zinc-800 text-white shadow-sm'
                : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800/50'
            }`}
          >
            <FileImage className="w-3.5 h-3.5 text-indigo-400" />
            <span>Photos</span>
            <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-zinc-950/80 text-zinc-400 font-mono">
              {photosCount}
            </span>
          </button>

          <button
            onClick={() => onFilterChange('video')}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-medium transition whitespace-nowrap ${
              filter === 'video'
                ? 'bg-zinc-800 text-white shadow-sm'
                : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800/50'
            }`}
          >
            <Film className="w-3.5 h-3.5 text-purple-400" />
            <span>Videos</span>
            <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-zinc-950/80 text-zinc-400 font-mono">
              {videosCount}
            </span>
          </button>
        </div>

        {/* Right tools: Sort order & Selection actions */}
        <div className="flex items-center justify-between sm:justify-end gap-3">
          <div className="flex items-center gap-2">
            <span className="text-xs text-zinc-500 hidden sm:inline flex items-center gap-1">
              <ArrowUpDown className="w-3 h-3" />
              Sort:
            </span>
            <select
              value={sortOrder}
              onChange={(e) => onSortChange(e.target.value as SortOrder)}
              className="bg-zinc-900 border border-zinc-800 text-xs text-zinc-300 rounded-xl px-3 py-1.5 focus:outline-none focus:ring-1 focus:ring-indigo-500 cursor-pointer"
            >
              <option value="newest">Newest First</option>
              <option value="oldest">Oldest First</option>
            </select>
          </div>

          {filteredItems.length > 0 && selectedIds.size === 0 && (
            <button
              onClick={onSelectAll}
              className="text-xs text-zinc-400 hover:text-zinc-200 px-3 py-1.5 rounded-lg hover:bg-zinc-800/60 transition"
            >
              Select All
            </button>
          )}
        </div>
      </div>

      {/* Floating Multi-select Action Bar */}
      {selectedIds.size > 0 && (
        <div className="sticky top-20 z-30 p-3.5 bg-zinc-900/95 border border-indigo-500/30 rounded-2xl shadow-2xl backdrop-blur-md flex flex-wrap items-center justify-between gap-3 animate-in fade-in slide-in-from-top-2">
          <div className="flex items-center gap-3">
            <button
              onClick={onClearSelection}
              className="p-1 rounded-lg text-zinc-400 hover:text-white hover:bg-zinc-800 transition"
              title="Clear selection"
            >
              <X className="w-4 h-4" />
            </button>
            <span className="text-xs font-semibold text-zinc-100">
              {selectedIds.size} item{selectedIds.size > 1 ? 's' : ''} selected
            </span>
            <span className="text-xs font-mono text-zinc-400">
              ({formatBytes(selectedBytes)})
            </span>
          </div>

          <div className="flex items-center gap-2.5">
            <button
              onClick={onBulkDownloadRequest}
              className="flex items-center gap-2 px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-medium rounded-xl shadow-md transition active:scale-95"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download Selected (ZIP)</span>
            </button>
            <button
              onClick={onBulkDeleteRequest}
              className="flex items-center gap-2 px-3.5 py-1.5 bg-rose-600/20 hover:bg-rose-600 border border-rose-500/30 hover:border-rose-600 text-rose-300 hover:text-white text-xs font-medium rounded-xl transition active:scale-95"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Delete Selected</span>
            </button>
          </div>
        </div>
      )}

      {/* Grid Content */}
      {isLoading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6">
          {[...Array(8)].map((_, i) => (
            <div
              key={i}
              className="aspect-square bg-zinc-900 border border-zinc-800/80 rounded-2xl animate-pulse"
            />
          ))}
        </div>
      ) : filteredItems.length === 0 ? (
        /* Empty state */
        <div className="py-20 text-center rounded-3xl border border-dashed border-zinc-800 bg-zinc-950/40 p-8 space-y-4">
          <div className="w-14 h-14 rounded-2xl bg-zinc-900 border border-zinc-800 flex items-center justify-center text-zinc-500 mx-auto">
            <FolderOpen className="w-7 h-7" />
          </div>
          <div>
            <h3 className="text-base font-semibold text-zinc-200">
              No media in this view
            </h3>
            <p className="text-xs text-zinc-400 max-w-sm mx-auto mt-1">
              {filter !== 'all'
                ? `No ${filter}s found. Try switching to "All" or upload new media.`
                : 'Your personal vault is empty. Click the Upload button to add original photos and videos.'}
            </p>
          </div>
        </div>
      ) : (
        /* Media Grid */
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6">
          {filteredItems.map((item, index) => (
            <MediaCard
              key={item.id}
              item={item}
              isSelected={selectedIds.has(item.id)}
              onSelectToggle={onSelectToggle}
              onClick={() => onItemClick(item, index)}
              onDeleteRequest={onDeleteRequest}
            />
          ))}
        </div>
      )}
    </div>
  );
};
