import React, { useState } from 'react';
import {
  X,
  Copy,
  Check,
  Globe,
  Database,
  Key,
  Shield,
  ExternalLink,
} from 'lucide-react';

interface ConfigGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ConfigGuideModal: React.FC<ConfigGuideModalProps> = ({
  isOpen,
  onClose,
}) => {
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  if (!isOpen) return null;

  const copyToClipboard = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2500);
  };

  const gitPushScript = `# 1. Initialize and add all files
git init
git add .
git commit -m "feat: complete ba. sha_as personal media gallery ready for Vercel"
git branch -M main

# 2. Add your GitHub repository as origin
git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPOSITORY.git

# 3. Push to GitHub
git push -u origin main`;

  const vercelEnvList = `VITE_ADMIN_PASSWORD=hinata
VITE_FIREBASE_API_KEY=AIzaSy...
VITE_FIREBASE_AUTH_DOMAIN=your-app.firebaseapp.com
VITE_FIREBASE_PROJECT_ID=your-project-id
VITE_FIREBASE_STORAGE_BUCKET=your-project-id.appspot.com
VITE_FIREBASE_MESSAGING_SENDER_ID=123456789
VITE_FIREBASE_APP_ID=1:123456789:web:abcdef`;

  const firestoreRules = `rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /gallery_media/{document=**} {
      // Anyone can read and browse files
      allow read: if true;
      // Allow write operations
      allow write: if true;
    }
  }
}`;

  const storageRules = `rules_version = '2';
service firebase.storage {
  match /b/{bucket}/o {
    match /gallery/{allPaths=**} {
      // Anyone can read and download exact original files
      allow read: if true;
      // Allow uploads and deletions
      allow write: if true;
    }
  }
}`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      <div
        className="w-full max-w-2xl bg-zinc-900 border border-zinc-800 rounded-2xl shadow-2xl flex flex-col max-h-[85vh] relative"
        role="dialog"
        aria-modal="true"
      >
        {/* Header */}
        <div className="p-6 border-b border-zinc-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center text-indigo-400">
              <Globe className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-semibold text-zinc-100">
                GitHub & Vercel Deployment Guide
              </h2>
              <p className="text-xs text-zinc-400">
                Steps to push to your GitHub repo and deploy seamlessly on Vercel
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-zinc-400 hover:text-zinc-200 p-1.5 rounded-lg hover:bg-zinc-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="p-6 overflow-y-auto space-y-6 text-xs text-zinc-300">
          {/* Step 1: Push to GitHub */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 font-semibold text-zinc-100">
                <span className="w-5 h-5 rounded-full bg-indigo-600 text-white flex items-center justify-center text-[10px]">
                  1
                </span>
                <span>Pushing to GitHub</span>
              </div>
              <button
                onClick={() => copyToClipboard(gitPushScript, 'git')}
                className="flex items-center gap-1.5 text-indigo-400 hover:text-indigo-300 px-2 py-1 rounded bg-indigo-500/10 hover:bg-indigo-500/20 transition"
              >
                {copiedKey === 'git' ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                    <span className="text-emerald-400">Copied</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>Copy Commands</span>
                  </>
                )}
              </button>
            </div>
            <pre className="p-3.5 bg-zinc-950 rounded-xl border border-zinc-800 font-mono text-[11px] text-zinc-300 overflow-x-auto whitespace-pre">
              {gitPushScript}
            </pre>
          </div>

          {/* Step 2: Deploy to Vercel */}
          <div className="space-y-2">
            <div className="flex items-center gap-2 font-semibold text-zinc-100">
              <span className="w-5 h-5 rounded-full bg-indigo-600 text-white flex items-center justify-center text-[10px]">
                2
              </span>
              <span>Deploying on Vercel</span>
            </div>
            <div className="p-3.5 bg-zinc-950/60 rounded-xl border border-zinc-800 space-y-2 text-zinc-300">
              <p>
                1. Go to <span className="text-white font-medium">vercel.com</span> and click <span className="text-indigo-400 font-medium">Add New Project</span>.
              </p>
              <p>
                2. Import your GitHub repository. Vercel automatically detects <span className="font-mono text-zinc-400">Vite</span> and uses <span className="font-mono text-zinc-400">vercel.json</span>.
              </p>
              <p>
                3. Under <span className="text-white font-medium">Environment Variables</span>, add your keys below:
              </p>
            </div>

            <div className="flex items-center justify-between pt-1">
              <span className="font-medium text-zinc-200">Environment Variables:</span>
              <button
                onClick={() => copyToClipboard(vercelEnvList, 'env')}
                className="flex items-center gap-1 text-indigo-400 hover:text-indigo-300"
              >
                {copiedKey === 'env' ? (
                  <span className="text-emerald-400 flex items-center gap-1">
                    <Check className="w-3.5 h-3.5" /> Copied
                  </span>
                ) : (
                  <span className="flex items-center gap-1">
                    <Copy className="w-3.5 h-3.5" /> Copy env vars
                  </span>
                )}
              </button>
            </div>
            <pre className="p-3 bg-zinc-950 rounded-xl border border-zinc-800 font-mono text-[11px] text-zinc-300 overflow-x-auto">
              {vercelEnvList}
            </pre>
          </div>

          {/* Step 3: Firebase Rules */}
          <div className="space-y-3 pt-2">
            <div className="flex items-center gap-2 font-semibold text-zinc-100">
              <span className="w-5 h-5 rounded-full bg-indigo-600 text-white flex items-center justify-center text-[10px]">
                3
              </span>
              <span>Firebase Security Rules</span>
            </div>
            <p className="text-zinc-400">
              These rules allow your friends to browse and download original files, while the gallery requires your admin password (<code className="text-indigo-400 font-mono font-bold">hinata</code>) for uploads and deletions:
            </p>

            {/* Firestore */}
            <div>
              <div className="flex items-center justify-between text-zinc-300 mb-1">
                <span className="font-mono text-indigo-300 font-medium">Firestore Rules:</span>
                <button
                  onClick={() => copyToClipboard(firestoreRules, 'firestore')}
                  className="text-indigo-400 hover:text-indigo-300 flex items-center gap-1"
                >
                  {copiedKey === 'firestore' ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                  Copy
                </button>
              </div>
              <pre className="p-2.5 bg-zinc-950 rounded-lg border border-zinc-800 font-mono text-[11px] text-zinc-400 overflow-x-auto">
                {firestoreRules}
              </pre>
            </div>

            {/* Storage */}
            <div>
              <div className="flex items-center justify-between text-zinc-300 mb-1">
                <span className="font-mono text-indigo-300 font-medium">Firebase Storage Rules:</span>
                <button
                  onClick={() => copyToClipboard(storageRules, 'storage')}
                  className="text-indigo-400 hover:text-indigo-300 flex items-center gap-1"
                >
                  {copiedKey === 'storage' ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                  Copy
                </button>
              </div>
              <pre className="p-2.5 bg-zinc-950 rounded-lg border border-zinc-800 font-mono text-[11px] text-zinc-400 overflow-x-auto">
                {storageRules}
              </pre>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-zinc-800 flex justify-end bg-zinc-900/50">
          <button
            onClick={onClose}
            className="px-5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold rounded-xl transition"
          >
            Got it
          </button>
        </div>
      </div>
    </div>
  );
};
