import React from 'react';
import { Camera, Upload, Database, ShieldCheck, Sparkles } from 'lucide-react';
import { isFirebaseConfigured } from '../lib/firebase';

interface HeaderProps {
  onUploadClick: () => void;
  onOpenConfigGuide: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  onUploadClick,
  onOpenConfigGuide,
}) => {
  return (
    <header className="w-full border-b border-zinc-800/80 bg-zinc-950/70 backdrop-blur-xl sticky top-0 z-40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          {/* Brand Logo & Name */}
          <div className="flex items-center gap-3.5">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-indigo-500 to-purple-600 p-[1px] shadow-lg shadow-indigo-500/20">
              <div className="w-full h-full bg-zinc-950 rounded-[15px] flex items-center justify-center">
                <Camera className="w-5 h-5 text-indigo-400" />
              </div>
            </div>
            <div>
              <span className="text-xl font-bold tracking-tight text-white font-mono">
                ba. sha_as
              </span>
              <span className="hidden sm:inline-block ml-2.5 px-2 py-0.5 rounded-full text-[10px] font-semibold bg-indigo-500/10 text-indigo-300 border border-indigo-500/20">
                100% Original Quality
              </span>
            </div>
          </div>

          {/* Right Header Navigation & Actions */}
          <div className="flex items-center gap-2.5 sm:gap-3.5">
            {/* Storage Status & Deployment Guide Button */}
            <button
              onClick={onOpenConfigGuide}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-medium text-zinc-400 hover:text-zinc-200 bg-zinc-900/60 hover:bg-zinc-800 border border-zinc-800 transition"
              title="Deployment & Firebase Configuration Guide"
            >
              <Database className="w-3.5 h-3.5 text-indigo-400" />
              <span className="hidden md:inline">
                {isFirebaseConfigured ? 'Firebase Cloud' : 'Storage / Vercel Guide'}
              </span>
              <span
                className={`w-2 h-2 rounded-full ${
                  isFirebaseConfigured ? 'bg-emerald-400' : 'bg-amber-400'
                }`}
              />
            </button>

            {/* Upload Button */}
            <button
              onClick={onUploadClick}
              className="flex items-center gap-2 px-4 py-2 sm:px-5 sm:py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs sm:text-sm font-semibold rounded-xl shadow-lg shadow-indigo-600/25 transition active:scale-[0.98]"
            >
              <Upload className="w-4 h-4" />
              <span>Upload</span>
              <ShieldCheck className="w-3.5 h-3.5 opacity-80" />
            </button>
          </div>
        </div>

        {/* Hero Banner Section */}
        <div className="pt-4 pb-8 sm:py-10 border-t border-zinc-900/80">
          <div className="max-w-2xl">
            <h1 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-white mb-2">
              memories with friends
            </h1>
            <p className="text-sm sm:text-base text-zinc-400 leading-relaxed font-light">
              High-definition uncompressed photo and video archive. Browse freely, download original uncompressed files with full fidelity, or authenticate as owner to manage.
            </p>
          </div>
        </div>
      </div>
    </header>
  );
};
