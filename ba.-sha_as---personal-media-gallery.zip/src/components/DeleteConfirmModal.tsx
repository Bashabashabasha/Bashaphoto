import React from 'react';
import { Trash2, AlertTriangle, X } from 'lucide-react';
import type { MediaItem } from '../types';
import { formatBytes } from '../lib/formatters';

interface DeleteConfirmModalProps {
  isOpen: boolean;
  itemsToDelete: MediaItem[];
  isDeleting: boolean;
  onConfirm: () => void;
  onClose: () => void;
}

export const DeleteConfirmModal: React.FC<DeleteConfirmModalProps> = ({
  isOpen,
  itemsToDelete,
  isDeleting,
  onConfirm,
  onClose,
}) => {
  if (!isOpen || itemsToDelete.length === 0) return null;

  const totalBytes = itemsToDelete.reduce((acc, item) => acc + item.size, 0);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div
        className="w-full max-w-md bg-zinc-900 border border-zinc-800 rounded-2xl shadow-2xl p-6 relative"
        role="dialog"
        aria-modal="true"
        aria-labelledby="delete-confirm-title"
      >
        <button
          onClick={onClose}
          disabled={isDeleting}
          className="absolute top-5 right-5 text-zinc-400 hover:text-zinc-200 p-1.5 rounded-lg hover:bg-zinc-800 transition disabled:opacity-50"
          aria-label="Close dialog"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3.5 mb-4">
          <div className="w-11 h-11 rounded-xl bg-rose-500/10 border border-rose-500/20 flex items-center justify-center text-rose-400 shrink-0">
            <Trash2 className="w-5 h-5" />
          </div>
          <div>
            <h2 id="delete-confirm-title" className="text-lg font-semibold text-zinc-100">
              Confirm Permanent Deletion
            </h2>
            <p className="text-xs text-zinc-400 mt-0.5">
              {itemsToDelete.length === 1
                ? 'Remove 1 item from gallery and storage'
                : `Remove ${itemsToDelete.length} items from gallery and storage`}
            </p>
          </div>
        </div>

        <div className="bg-zinc-950/60 border border-zinc-800/80 rounded-xl p-3.5 my-4 max-h-48 overflow-y-auto space-y-2">
          {itemsToDelete.map((item) => (
            <div key={item.id} className="flex items-center justify-between text-xs text-zinc-300">
              <span className="truncate pr-2 font-mono text-zinc-400">{item.name}</span>
              <span className="shrink-0 text-zinc-500">{formatBytes(item.size)}</span>
            </div>
          ))}
        </div>

        <div className="flex items-center justify-between text-xs text-zinc-400 mb-5 px-1">
          <span>Total Size to be freed:</span>
          <span className="font-semibold text-zinc-200">{formatBytes(totalBytes)}</span>
        </div>

        <div className="flex items-start gap-2.5 p-3 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-300/90 text-xs mb-5">
          <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5 text-amber-400" />
          <span>
            This action is irreversible. The exact original files will be deleted from Firebase Storage and Firestore.
          </span>
        </div>

        <div className="flex items-center justify-end gap-2.5">
          <button
            type="button"
            onClick={onClose}
            disabled={isDeleting}
            className="px-4 py-2 text-xs font-medium text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800 rounded-xl transition disabled:opacity-50"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={onConfirm}
            disabled={isDeleting}
            className="flex items-center gap-2 px-5 py-2.5 bg-rose-600 hover:bg-rose-500 disabled:opacity-50 disabled:cursor-not-allowed text-white text-xs font-semibold rounded-xl shadow-lg shadow-rose-600/20 transition active:scale-[0.98]"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>{isDeleting ? 'Deleting...' : 'Delete Permanently'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
