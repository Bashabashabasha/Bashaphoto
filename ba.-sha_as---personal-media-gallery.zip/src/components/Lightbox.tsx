import React, { useEffect, useState, useRef } from 'react';
import {
  X,
  ChevronLeft,
  ChevronRight,
  Download,
  Calendar,
  HardDrive,
  Maximize2,
} from 'lucide-react';
import type { MediaItem } from '../types';
import { formatBytes, formatDate } from '../lib/formatters';
import { downloadOriginalFile } from '../lib/download';

interface LightboxProps {
  items: MediaItem[];
  currentIndex: number;
  isOpen: boolean;
  onClose: () => void;
  onIndexChange: (index: number) => void;
  onDeleteRequest?: (item: MediaItem) => void;
}

export const Lightbox: React.FC<LightboxProps> = ({
  items,
  currentIndex,
  isOpen,
  onClose,
  onIndexChange,
}) => {
  const currentItem = items[currentIndex];
  const [touchStart, setTouchStart] = useState<number | null>(null);
  const [touchEnd, setTouchEnd] = useState<number | null>(null);
  const videoRef = useRef<HTMLVideoElement>(null);

  const prevItem = () => {
    if (currentIndex > 0) {
      onIndexChange(currentIndex - 1);
    } else {
      onIndexChange(items.length - 1);
    }
  };

  const nextItem = () => {
    if (currentIndex < items.length - 1) {
      onIndexChange(currentIndex + 1);
    } else {
      onIndexChange(0);
    }
  };

  // Keyboard navigation
  useEffect(() => {
    if (!isOpen) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      } else if (e.key === 'ArrowLeft') {
        prevItem();
      } else if (e.key === 'ArrowRight') {
        nextItem();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, currentIndex, items.length]);

  // Touch swipe support for mobile
  const minSwipeDistance = 50;

  const onTouchStart = (e: React.TouchEvent) => {
    setTouchEnd(null);
    setTouchStart(e.targetTouches[0].clientX);
  };

  const onTouchMove = (e: React.TouchEvent) => {
    setTouchEnd(e.targetTouches[0].clientX);
  };

  const onTouchEnd = () => {
    if (!touchStart || !touchEnd) return;
    const distance = touchStart - touchEnd;
    const isLeftSwipe = distance > minSwipeDistance;
    const isRightSwipe = distance < -minSwipeDistance;

    if (isLeftSwipe) {
      nextItem();
    } else if (isRightSwipe) {
      prevItem();
    }
  };

  if (!isOpen || !currentItem) return null;

  return (
    <div
      className="fixed inset-0 z-50 bg-black/95 backdrop-blur-md flex flex-col justify-between animate-in fade-in duration-200 select-none"
      onTouchStart={onTouchStart}
      onTouchMove={onTouchMove}
      onTouchEnd={onTouchEnd}
    >
      {/* Top Bar */}
      <div className="flex items-center justify-between p-4 sm:px-6 bg-gradient-to-b from-black/80 to-transparent z-10">
        <div className="flex items-center gap-4 min-w-0">
          <div className="flex flex-col">
            <span className="text-xs font-mono text-zinc-400">
              {currentIndex + 1} / {items.length}
            </span>
            <h3 className="text-sm font-semibold text-zinc-100 truncate max-w-xs sm:max-w-md">
              {currentItem.name}
            </h3>
          </div>

          <div className="hidden sm:flex items-center gap-3 text-xs text-zinc-400 pl-3 border-l border-zinc-800">
            <span className="flex items-center gap-1.5">
              <HardDrive className="w-3.5 h-3.5 text-zinc-500" />
              {formatBytes(currentItem.size)}
            </span>
            <span>·</span>
            <span className="flex items-center gap-1.5">
              <Calendar className="w-3.5 h-3.5 text-zinc-500" />
              {formatDate(currentItem.uploadDate)}
            </span>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* Download Original button */}
          <button
            onClick={() => downloadOriginalFile(currentItem.downloadUrl, currentItem.name)}
            className="flex items-center gap-2 px-3.5 py-2 bg-zinc-800/80 hover:bg-zinc-700 text-zinc-100 text-xs font-medium rounded-xl border border-zinc-700/50 backdrop-blur-sm transition active:scale-95"
            title="Download Original Quality"
          >
            <Download className="w-4 h-4 text-indigo-400" />
            <span className="hidden sm:inline">Download Original</span>
          </button>

          {/* Close Lightbox */}
          <button
            onClick={onClose}
            className="p-2 text-zinc-400 hover:text-zinc-100 rounded-xl hover:bg-zinc-800/80 transition"
            aria-label="Close lightbox"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Main Media Viewer */}
      <div className="relative flex-1 flex items-center justify-center p-2 sm:p-6 overflow-hidden">
        {/* Previous Button */}
        {items.length > 1 && (
          <button
            onClick={(e) => {
              e.stopPropagation();
              prevItem();
            }}
            className="absolute left-4 top-1/2 -translate-y-1/2 p-3 rounded-full bg-zinc-900/60 hover:bg-zinc-800 border border-zinc-800 text-zinc-300 hover:text-white transition z-20 backdrop-blur-md hidden sm:flex items-center justify-center"
            aria-label="Previous item"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>
        )}

        {/* Media content */}
        <div className="max-w-full max-h-full flex items-center justify-center">
          {currentItem.type === 'video' ? (
            <video
              ref={videoRef}
              key={currentItem.id}
              src={currentItem.downloadUrl}
              controls
              autoPlay
              playsInline
              className="max-h-[82vh] max-w-[94vw] rounded-lg shadow-2xl object-contain bg-black"
            />
          ) : (
            <img
              key={currentItem.id}
              src={currentItem.downloadUrl}
              alt={currentItem.name}
              className="max-h-[82vh] max-w-[94vw] rounded-lg shadow-2xl object-contain animate-in zoom-in-95 duration-200"
            />
          )}
        </div>

        {/* Next Button */}
        {items.length > 1 && (
          <button
            onClick={(e) => {
              e.stopPropagation();
              nextItem();
            }}
            className="absolute right-4 top-1/2 -translate-y-1/2 p-3 rounded-full bg-zinc-900/60 hover:bg-zinc-800 border border-zinc-800 text-zinc-300 hover:text-white transition z-20 backdrop-blur-md hidden sm:flex items-center justify-center"
            aria-label="Next item"
          >
            <ChevronRight className="w-6 h-6" />
          </button>
        )}
      </div>

      {/* Bottom info for mobile */}
      <div className="sm:hidden p-3 bg-zinc-950/80 border-t border-zinc-900 flex items-center justify-between text-[11px] text-zinc-400">
        <span>{formatBytes(currentItem.size)}</span>
        <span>{formatDate(currentItem.uploadDate)}</span>
        <span className="text-zinc-500">Swipe ← → to browse</span>
      </div>
    </div>
  );
};
