import React, { useState } from 'react';
import { Play, Download, Trash2, Check } from 'lucide-react';
import type { MediaItem } from '../types';
import { formatBytes, formatDate, formatDuration } from '../lib/formatters';
import { downloadOriginalFile } from '../lib/download';

interface MediaCardProps {
  item: MediaItem;
  isSelected: boolean;
  onSelectToggle: (item: MediaItem) => void;
  onClick: () => void;
  onDeleteRequest: (item: MediaItem) => void;
}

export const MediaCard: React.FC<MediaCardProps> = ({
  item,
  isSelected,
  onSelectToggle,
  onClick,
  onDeleteRequest,
}) => {
  const [isLoaded, setIsLoaded] = useState(false);

  const handleDownload = (e: React.MouseEvent) => {
    e.stopPropagation();
    downloadOriginalFile(item.downloadUrl, item.name);
  };

  const handleDelete = (e: React.MouseEvent) => {
    e.stopPropagation();
    onDeleteRequest(item);
  };

  const handleCheckbox = (e: React.MouseEvent) => {
    e.stopPropagation();
    onSelectToggle(item);
  };

  return (
    <div
      onClick={onClick}
      className={`group relative bg-zinc-900 border rounded-2xl overflow-hidden cursor-pointer transition-all duration-300 hover:shadow-2xl hover:shadow-indigo-500/10 hover:-translate-y-1 ${
        isSelected
          ? 'border-indigo-500 ring-2 ring-indigo-500/30'
          : 'border-zinc-800/80 hover:border-zinc-700'
      }`}
    >
      {/* Thumbnail Aspect Container */}
      <div className="relative aspect-square sm:aspect-[4/3] bg-zinc-950 overflow-hidden">
        {/* Placeholder skeleton before load */}
        {!isLoaded && (
          <div className="absolute inset-0 bg-zinc-900/60 animate-pulse" />
        )}

        {item.type === 'video' ? (
          <>
            <video
              src={item.downloadUrl}
              preload="metadata"
              onLoadedData={() => setIsLoaded(true)}
              className={`w-full h-full object-cover transition-all duration-500 group-hover:scale-105 ${
                isLoaded ? 'opacity-100' : 'opacity-0'
              }`}
            />
            {/* Video Play Overlay */}
            <div className="absolute inset-0 flex items-center justify-center bg-black/25 group-hover:bg-black/10 transition-colors pointer-events-none">
              <div className="w-12 h-12 rounded-full bg-zinc-950/80 border border-white/20 flex items-center justify-center text-white shadow-xl backdrop-blur-md group-hover:scale-110 transition-transform">
                <Play className="w-5 h-5 fill-current translate-x-0.5 text-indigo-400" />
              </div>
            </div>

            {/* Video Duration Badge */}
            {item.duration && (
              <div className="absolute bottom-2.5 right-2.5 px-2 py-0.5 rounded-md bg-black/75 backdrop-blur-md text-[11px] font-mono font-medium text-zinc-200 border border-white/10">
                {formatDuration(item.duration)}
              </div>
            )}
          </>
        ) : (
          <img
            src={item.downloadUrl}
            alt={item.name}
            loading="lazy"
            onLoad={() => setIsLoaded(true)}
            className={`w-full h-full object-cover transition-all duration-500 group-hover:scale-105 ${
              isLoaded ? 'opacity-100' : 'opacity-0'
            }`}
          />
        )}

        {/* Multi-select Checkbox Checkmark */}
        <div
          onClick={handleCheckbox}
          className={`absolute top-2.5 left-2.5 z-10 w-6 h-6 rounded-lg border flex items-center justify-center transition-all ${
            isSelected
              ? 'bg-indigo-600 border-indigo-400 text-white'
              : 'bg-zinc-900/70 border-zinc-700/80 text-transparent hover:border-zinc-500 backdrop-blur-md opacity-0 group-hover:opacity-100'
          }`}
          title={isSelected ? 'Deselect item' : 'Select item'}
        >
          <Check className="w-3.5 h-3.5 stroke-[3]" />
        </div>

        {/* Hover Quick Actions on Top Right */}
        <div className="absolute top-2.5 right-2.5 z-10 flex items-center gap-1.5 opacity-0 group-hover:opacity-100 transition-opacity">
          {/* Direct Download Button */}
          <button
            onClick={handleDownload}
            className="p-2 rounded-lg bg-zinc-900/80 hover:bg-zinc-800 text-zinc-300 hover:text-white border border-zinc-700/60 backdrop-blur-md transition shadow-lg"
            title="Download Original Quality"
          >
            <Download className="w-3.5 h-3.5 text-indigo-400" />
          </button>

          {/* Delete Button */}
          <button
            onClick={handleDelete}
            className="p-2 rounded-lg bg-zinc-900/80 hover:bg-rose-950/80 text-zinc-300 hover:text-rose-400 border border-zinc-700/60 hover:border-rose-800/80 backdrop-blur-md transition shadow-lg"
            title="Delete File (Admin Required)"
          >
            <Trash2 className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Card Metadata Info Bar */}
      <div className="p-3.5 bg-zinc-900/90">
        <div className="flex items-center justify-between gap-2 mb-1">
          <p className="text-xs font-medium text-zinc-200 truncate font-mono">
            {item.name}
          </p>
          <span className="text-[11px] font-mono text-zinc-500 shrink-0">
            {formatBytes(item.size)}
          </span>
        </div>
        <div className="flex items-center justify-between text-[11px] text-zinc-400">
          <span>{formatDate(item.uploadDate)}</span>
          <span className="text-indigo-400/90 font-medium capitalize">
            {item.type}
          </span>
        </div>
      </div>
    </div>
  );
};
