import JSZip from 'jszip';
import type { MediaItem } from '../types';

/**
 * Downloads a single file directly with its exact original filename and zero alteration.
 */
export async function downloadOriginalFile(url: string, filename: string): Promise<void> {
  try {
    const response = await fetch(url, { mode: 'cors' });
    if (!response.ok) {
      throw new Error(`Failed to fetch file: ${response.statusText}`);
    }
    const blob = await response.blob();
    const objectUrl = URL.createObjectURL(blob);
    
    const link = document.createElement('a');
    link.href = objectUrl;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    setTimeout(() => URL.revokeObjectURL(objectUrl), 10000);
  } catch {
    // Fallback direct download link if CORS prevents fetch
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    link.target = '_blank';
    link.rel = 'noopener noreferrer';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }
}

/**
 * Bundles multiple files into an uncompressed ZIP archive (STORE mode)
 * preserving exact original bytes and filenames.
 */
export async function downloadSelectedAsZip(
  items: MediaItem[],
  onProgress?: (progress: number, message: string) => void
): Promise<void> {
  if (items.length === 0) return;
  
  if (items.length === 1) {
    return downloadOriginalFile(items[0].downloadUrl, items[0].name);
  }

  const zip = new JSZip();
  const folder = zip.folder('ba_sha_as_originals');
  const usedNames = new Set<string>();

  for (let i = 0; i < items.length; i++) {
    const item = items[i];
    if (onProgress) {
      const percent = Math.round((i / items.length) * 80);
      onProgress(percent, `Fetching ${item.name} (${i + 1}/${items.length})...`);
    }

    try {
      const response = await fetch(item.downloadUrl);
      if (!response.ok) throw new Error('Fetch failed');
      const blob = await response.blob();
      
      let safeName = item.name;
      if (usedNames.has(safeName)) {
        const dotIndex = safeName.lastIndexOf('.');
        const base = dotIndex !== -1 ? safeName.substring(0, dotIndex) : safeName;
        const ext = dotIndex !== -1 ? safeName.substring(dotIndex) : '';
        safeName = `${base}_${i + 1}${ext}`;
      }
      usedNames.add(safeName);

      folder?.file(safeName, blob, { binary: true });
    } catch (err) {
      console.warn(`Could not bundle file ${item.name}:`, err);
    }
  }

  if (onProgress) {
    onProgress(85, 'Assembling uncompressed ZIP archive...');
  }

  // compression: "STORE" ensures 0% compression, 100% original quality
  const content = await zip.generateAsync(
    {
      type: 'blob',
      compression: 'STORE',
    },
    (metadata) => {
      if (onProgress) {
        const percent = Math.round(85 + (metadata.percent * 0.15));
        onProgress(percent, `Packaging archive: ${Math.round(metadata.percent)}%`);
      }
    }
  );

  if (onProgress) {
    onProgress(100, 'Download ready!');
  }

  const zipUrl = URL.createObjectURL(content);
  const link = document.createElement('a');
  link.href = zipUrl;
  link.download = `ba_sha_as_memories_${Date.now()}.zip`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);

  setTimeout(() => URL.revokeObjectURL(zipUrl), 15000);
}
