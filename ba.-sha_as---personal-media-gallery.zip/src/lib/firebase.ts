import { initializeApp, getApps, type FirebaseApp } from 'firebase/app';
import {
  getFirestore,
  collection,
  getDocs,
  addDoc,
  deleteDoc,
  doc,
  query,
  orderBy,
  type Firestore,
} from 'firebase/firestore';
import {
  getStorage,
  ref,
  uploadBytesResumable,
  getDownloadURL,
  deleteObject,
  type FirebaseStorage,
} from 'firebase/storage';
import type { MediaItem } from '../types';

// Read Firebase configuration from environment variables
const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY,
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN,
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID,
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID,
  appId: import.meta.env.VITE_FIREBASE_APP_ID,
};

export const isFirebaseConfigured = Boolean(
  firebaseConfig.apiKey &&
  firebaseConfig.projectId &&
  firebaseConfig.storageBucket
);

let app: FirebaseApp | null = null;
let db: Firestore | null = null;
let storage: FirebaseStorage | null = null;

if (isFirebaseConfigured) {
  try {
    app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApps()[0];
    db = getFirestore(app);
    storage = getStorage(app);
  } catch (error) {
    console.error('Failed to initialize Firebase SDK:', error);
  }
}

// Initial sample media so the gallery is beautiful and interactive right away
const INITIAL_DEMO_MEDIA: MediaItem[] = [
  {
    id: 'demo-photo-1',
    name: 'mountain_sunset_friends.jpg',
    type: 'image',
    size: 4892010, // ~4.9 MB
    uploadDate: Date.now() - 1000 * 60 * 60 * 24 * 3, // 3 days ago
    downloadUrl: 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=2400&q=100',
    width: 2400,
    height: 1600,
    isLocalOnly: true,
  },
  {
    id: 'demo-photo-2',
    name: 'summer_beach_campfire.jpg',
    type: 'image',
    size: 6140520, // ~6.1 MB
    uploadDate: Date.now() - 1000 * 60 * 60 * 24 * 7, // 7 days ago
    downloadUrl: 'https://images.unsplash.com/photo-1517457373958-b7bdd4587205?auto=format&fit=crop&w=2400&q=100',
    width: 2400,
    height: 1600,
    isLocalOnly: true,
  },
  {
    id: 'demo-video-1',
    name: 'coastal_waves_drone_4k.mp4',
    type: 'video',
    size: 45219000, // ~45.2 MB
    uploadDate: Date.now() - 1000 * 60 * 60 * 24 * 12,
    downloadUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
    duration: 15,
    isLocalOnly: true,
  },
  {
    id: 'demo-photo-3',
    name: 'tokyo_night_streets.jpg',
    type: 'image',
    size: 5240180, // ~5.2 MB
    uploadDate: Date.now() - 1000 * 60 * 60 * 24 * 18,
    downloadUrl: 'https://images.unsplash.com/photo-1503899036084-c55cdd92da26?auto=format&fit=crop&w=2400&q=100',
    width: 2400,
    height: 1600,
    isLocalOnly: true,
  },
  {
    id: 'demo-video-2',
    name: 'friends_roadtrip_moment.mp4',
    type: 'video',
    size: 28410200, // ~28.4 MB
    uploadDate: Date.now() - 1000 * 60 * 60 * 24 * 25,
    downloadUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyBlazes.mp4',
    duration: 15,
    isLocalOnly: true,
  },
  {
    id: 'demo-photo-4',
    name: 'stargazing_campout.jpg',
    type: 'image',
    size: 7320490, // ~7.3 MB
    uploadDate: Date.now() - 1000 * 60 * 60 * 24 * 32,
    downloadUrl: 'https://images.unsplash.com/photo-1519681393784-d120267933ba?auto=format&fit=crop&w=2400&q=100',
    width: 2400,
    height: 1600,
    isLocalOnly: true,
  },
];

const LOCAL_STORAGE_KEY = 'ba_sha_as_local_items_v1';

function getLocalItems(): MediaItem[] {
  try {
    const raw = localStorage.getItem(LOCAL_STORAGE_KEY);
    if (!raw) return INITIAL_DEMO_MEDIA;
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) && parsed.length > 0 ? parsed : INITIAL_DEMO_MEDIA;
  } catch {
    return INITIAL_DEMO_MEDIA;
  }
}

function saveLocalItems(items: MediaItem[]) {
  try {
    localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(items));
  } catch (e) {
    console.warn('Could not save to localStorage', e);
  }
}

/**
 * Fetch all media items:
 * Uses Cloud Firestore when configured, or persistent fallback.
 */
export async function getMediaItems(): Promise<MediaItem[]> {
  if (isFirebaseConfigured && db) {
    try {
      const q = query(collection(db, 'gallery_media'), orderBy('uploadDate', 'desc'));
      const snapshot = await getDocs(q);
      const items: MediaItem[] = [];
      snapshot.forEach((docSnap) => {
        const data = docSnap.data();
        items.push({
          id: docSnap.id,
          name: data.name || 'Untitled',
          type: data.type === 'video' ? 'video' : 'image',
          size: Number(data.size) || 0,
          uploadDate: Number(data.uploadDate) || Date.now(),
          downloadUrl: data.downloadUrl || '',
          storagePath: data.storagePath || '',
          width: data.width,
          height: data.height,
          duration: data.duration,
        });
      });
      return items;
    } catch (err) {
      console.warn('Firestore fetch failed, falling back to local vault:', err);
    }
  }

  return getLocalItems();
}

/**
 * Upload an original uncompressed file to Firebase Storage.
 * Uses uploadBytesResumable with byte-level progress reporting and zero re-encoding.
 */
export async function uploadMediaItem(
  file: File,
  onProgress: (progress: number, transferredBytes: number, totalBytes: number) => void
): Promise<MediaItem> {
  const isVideo = file.type.startsWith('video/');
  const type: 'image' | 'video' = isVideo ? 'video' : 'image';
  const timestamp = Date.now();
  const safeFilename = `${timestamp}_${file.name.replace(/[^a-zA-Z0-9._-]/g, '_')}`;

  // If Firebase Storage is configured, perform real upload
  if (isFirebaseConfigured && storage && db) {
    const storagePath = `gallery/${type}s/${safeFilename}`;
    const fileRef = ref(storage, storagePath);

    return new Promise<MediaItem>((resolve, reject) => {
      // Store exact original file with its natural contentType - zero compression or downscaling
      const uploadTask = uploadBytesResumable(fileRef, file, {
        contentType: file.type || (isVideo ? 'video/mp4' : 'image/jpeg'),
      });

      uploadTask.on(
        'state_changed',
        (snapshot) => {
          const progress = Math.round(
            (snapshot.bytesTransferred / snapshot.totalBytes) * 100
          );
          onProgress(progress, snapshot.bytesTransferred, snapshot.totalBytes);
        },
        (error) => {
          console.error('Firebase Storage upload error:', error);
          reject(error);
        },
        async () => {
          try {
            const downloadUrl = await getDownloadURL(uploadTask.snapshot.ref);

            // Save metadata in Firestore
            const docRef = await addDoc(collection(db!, 'gallery_media'), {
              name: file.name, // original filename preserved
              type,
              size: file.size, // original exact size preserved
              uploadDate: timestamp,
              downloadUrl,
              storagePath,
            });

            const newItem: MediaItem = {
              id: docRef.id,
              name: file.name,
              type,
              size: file.size,
              uploadDate: timestamp,
              downloadUrl,
              storagePath,
            };

            resolve(newItem);
          } catch (err) {
            reject(err);
          }
        }
      );
    });
  }

  // Graceful fallback for demo or unconfigured environments:
  // Emulates realistic upload progress for large files and creates an object URL of original file
  return new Promise<MediaItem>((resolve) => {
    let currentTransferred = 0;
    const chunkSize = Math.max(500000, Math.round(file.size / 20));
    const interval = setInterval(() => {
      currentTransferred = Math.min(file.size, currentTransferred + chunkSize);
      const progress = Math.round((currentTransferred / file.size) * 100);
      onProgress(progress, currentTransferred, file.size);

      if (currentTransferred >= file.size) {
        clearInterval(interval);
        const downloadUrl = URL.createObjectURL(file);
        const newItem: MediaItem = {
          id: `local-${timestamp}-${Math.random().toString(36).substring(2, 8)}`,
          name: file.name,
          type,
          size: file.size,
          uploadDate: timestamp,
          downloadUrl,
          isLocalOnly: true,
        };

        const existing = getLocalItems();
        saveLocalItems([newItem, ...existing]);
        resolve(newItem);
      }
    }, 100);
  });
}

/**
 * Delete a media item from Firebase Storage and Cloud Firestore.
 */
export async function deleteMediaItem(item: MediaItem): Promise<void> {
  if (isFirebaseConfigured && storage && db && item.storagePath) {
    try {
      const fileRef = ref(storage, item.storagePath);
      await deleteObject(fileRef);
    } catch (err) {
      console.warn('Storage delete warning:', err);
    }

    try {
      await deleteDoc(doc(db, 'gallery_media', item.id));
      return;
    } catch (err) {
      console.error('Firestore delete error:', err);
      throw err;
    }
  }

  // Local fallback
  const existing = getLocalItems();
  const updated = existing.filter((m) => m.id !== item.id);
  saveLocalItems(updated);
}
