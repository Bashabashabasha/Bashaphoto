export type MediaType = 'image' | 'video';

export interface MediaItem {
  id: string;
  name: string;
  type: MediaType;
  size: number; // in bytes
  uploadDate: number; // timestamp
  downloadUrl: string;
  storagePath?: string;
  width?: number;
  height?: number;
  duration?: number; // duration in seconds for video
  isLocalOnly?: boolean;
}

export type UploadStatus = 'pending' | 'uploading' | 'completed' | 'error';

export interface UploadItem {
  id: string;
  file: File;
  name: string;
  size: number;
  type: MediaType;
  progress: number; // 0 to 100
  uploadedBytes: number;
  status: UploadStatus;
  error?: string;
  downloadUrl?: string;
}

export type FilterCategory = 'all' | 'image' | 'video';
export type SortOrder = 'newest' | 'oldest';

export interface ToastMessage {
  id: string;
  type: 'success' | 'error' | 'info';
  title: string;
  message?: string;
}
