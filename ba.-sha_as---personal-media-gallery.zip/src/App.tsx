/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useCallback } from 'react';
import type {
  MediaItem,
  FilterCategory,
  SortOrder,
  ToastMessage,
} from './types';
import { getMediaItems, deleteMediaItem } from './lib/firebase';
import { downloadSelectedAsZip } from './lib/download';
import { Header } from './components/Header';
import { Gallery } from './components/Gallery';
import { Lightbox } from './components/Lightbox';
import { UploadModal } from './components/UploadModal';
import { PasswordModal } from './components/PasswordModal';
import { DeleteConfirmModal } from './components/DeleteConfirmModal';
import { ToastContainer } from './components/Toast';
import { ConfigGuideModal } from './components/ConfigGuideModal';

export default function App() {
  const [items, setItems] = useState<MediaItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [filter, setFilter] = useState<FilterCategory>('all');
  const [sortOrder, setSortOrder] = useState<SortOrder>('newest');
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());

  // Lightbox
  const [lightboxIndex, setLightboxIndex] = useState<number | null>(null);

  // Modals
  const [isUploadModalOpen, setIsUploadModalOpen] = useState(false);
  const [isConfigGuideOpen, setIsConfigGuideOpen] = useState(false);
  const [passwordModalState, setPasswordModalState] = useState<{
    isOpen: boolean;
    actionTitle: string;
    onSuccessAction: () => void;
  }>({
    isOpen: false,
    actionTitle: '',
    onSuccessAction: () => {},
  });

  const [deleteConfirmState, setDeleteConfirmState] = useState<{
    isOpen: boolean;
    items: MediaItem[];
    isDeleting: boolean;
  }>({
    isOpen: false,
    items: [],
    isDeleting: false,
  });

  // Toasts
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  const addToast = useCallback(
    (type: 'success' | 'error' | 'info', title: string, message?: string) => {
      const id = `${Date.now()}-${Math.random()}`;
      setToasts((prev) => [...prev, { id, type, title, message }]);
    },
    []
  );

  const removeToast = useCallback((id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  // Fetch media on mount
  useEffect(() => {
    let mounted = true;
    const loadItems = async () => {
      try {
        setIsLoading(true);
        const data = await getMediaItems();
        if (mounted) {
          setItems(data);
        }
      } catch (err: any) {
        if (mounted) {
          addToast('error', 'Failed to load media', err?.message);
        }
      } finally {
        if (mounted) {
          setIsLoading(false);
        }
      }
    };

    loadItems();
    return () => {
      mounted = false;
    };
  }, [addToast]);

  // Gate actions with PasswordModal
  const triggerPasswordGate = (actionTitle: string, callback: () => void) => {
    setPasswordModalState({
      isOpen: true,
      actionTitle,
      onSuccessAction: () => {
        setPasswordModalState((prev) => ({ ...prev, isOpen: false }));
        callback();
      },
    });
  };

  // Upload handling
  const handleUploadClick = () => {
    triggerPasswordGate('Upload Media', () => {
      setIsUploadModalOpen(true);
    });
  };

  const handleItemUploaded = (newItem: MediaItem) => {
    setItems((prev) => [newItem, ...prev]);
    addToast('success', 'File added to gallery', newItem.name);
  };

  // Single delete request
  const handleDeleteRequest = (item: MediaItem) => {
    triggerPasswordGate(`Delete "${item.name}"`, () => {
      setDeleteConfirmState({
        isOpen: true,
        items: [item],
        isDeleting: false,
      });
    });
  };

  // Bulk delete request
  const handleBulkDeleteRequest = () => {
    const selectedItems = items.filter((i) => selectedIds.has(i.id));
    if (selectedItems.length === 0) return;

    triggerPasswordGate(`Delete ${selectedItems.length} items`, () => {
      setDeleteConfirmState({
        isOpen: true,
        items: selectedItems,
        isDeleting: false,
      });
    });
  };

  // Confirm delete execution
  const executeDelete = async () => {
    const itemsToDelete = deleteConfirmState.items;
    if (itemsToDelete.length === 0) return;

    setDeleteConfirmState((prev) => ({ ...prev, isDeleting: true }));

    try {
      for (const item of itemsToDelete) {
        await deleteMediaItem(item);
      }

      const deletedIds = new Set(itemsToDelete.map((i) => i.id));
      setItems((prev) => prev.filter((i) => !deletedIds.has(i.id)));
      setSelectedIds((prev) => {
        const next = new Set(prev);
        deletedIds.forEach((id) => next.delete(id));
        return next;
      });

      setDeleteConfirmState({ isOpen: false, items: [], isDeleting: false });
      addToast(
        'success',
        'Permanently deleted',
        `Removed ${itemsToDelete.length} ${itemsToDelete.length === 1 ? 'file' : 'files'} from storage.`
      );
    } catch (err: any) {
      setDeleteConfirmState((prev) => ({ ...prev, isDeleting: false }));
      addToast('error', 'Deletion failed', err?.message || 'Could not delete item(s)');
    }
  };

  // Bulk download as uncompressed ZIP
  const handleBulkDownload = async () => {
    const selectedItems = items.filter((i) => selectedIds.has(i.id));
    if (selectedItems.length === 0) return;

    addToast('info', 'Preparing ZIP bundle', 'Assembling uncompressed original files...');

    try {
      await downloadSelectedAsZip(selectedItems, (percent, msg) => {
        if (percent === 100) {
          addToast('success', 'Download ready', msg);
        }
      });
    } catch (err: any) {
      addToast('error', 'Download bundle failed', err?.message);
    }
  };

  // Selection handlers
  const handleSelectToggle = (item: MediaItem) => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(item.id)) {
        next.delete(item.id);
      } else {
        next.add(item.id);
      }
      return next;
    });
  };

  const handleSelectAll = () => {
    setSelectedIds(new Set(items.map((i) => i.id)));
  };

  const handleClearSelection = () => {
    setSelectedIds(new Set());
  };

  // Lightbox click
  const handleItemClick = (_item: MediaItem, index: number) => {
    setLightboxIndex(index);
  };

  return (
    <div className="min-h-screen bg-[#090a0f] text-zinc-100 flex flex-col selection:bg-indigo-500/30">
      {/* Header with Title "ba. sha_as" and Tagline "memories with friends" */}
      <Header
        onUploadClick={handleUploadClick}
        onOpenConfigGuide={() => setIsConfigGuideOpen(true)}
      />

      {/* Main Gallery Area */}
      <main className="flex-1">
        <Gallery
          items={items}
          isLoading={isLoading}
          filter={filter}
          sortOrder={sortOrder}
          selectedIds={selectedIds}
          onFilterChange={setFilter}
          onSortChange={setSortOrder}
          onItemClick={handleItemClick}
          onSelectToggle={handleSelectToggle}
          onSelectAll={handleSelectAll}
          onClearSelection={handleClearSelection}
          onDeleteRequest={handleDeleteRequest}
          onBulkDeleteRequest={handleBulkDeleteRequest}
          onBulkDownloadRequest={handleBulkDownload}
        />
      </main>

      {/* Footer */}
      <footer className="w-full border-t border-zinc-900 bg-zinc-950/80 py-8 px-4 text-center text-xs text-zinc-500">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <span className="font-mono font-semibold text-zinc-300">ba. sha_as</span>
            <span>·</span>
            <span>memories with friends</span>
          </div>
          <p className="text-zinc-600 text-[11px]">
            Uncompressed Original Quality · Zero Transcoding · Password-Protected Archive
          </p>
        </div>
      </footer>

      {/* Fullscreen Lightbox */}
      {lightboxIndex !== null && (
        <Lightbox
          items={items}
          currentIndex={lightboxIndex}
          isOpen={lightboxIndex !== null}
          onClose={() => setLightboxIndex(null)}
          onIndexChange={(newIndex) => setLightboxIndex(newIndex)}
        />
      )}

      {/* Upload Modal (opened after password verification) */}
      <UploadModal
        isOpen={isUploadModalOpen}
        onClose={() => setIsUploadModalOpen(false)}
        onItemUploaded={handleItemUploaded}
      />

      {/* Admin Password Gate Modal */}
      <PasswordModal
        isOpen={passwordModalState.isOpen}
        actionTitle={passwordModalState.actionTitle}
        onSuccess={passwordModalState.onSuccessAction}
        onClose={() => setPasswordModalState((prev) => ({ ...prev, isOpen: false }))}
      />

      {/* Delete Confirmation Modal */}
      <DeleteConfirmModal
        isOpen={deleteConfirmState.isOpen}
        itemsToDelete={deleteConfirmState.items}
        isDeleting={deleteConfirmState.isDeleting}
        onConfirm={executeDelete}
        onClose={() =>
          setDeleteConfirmState({ isOpen: false, items: [], isDeleting: false })
        }
      />

      {/* Deployment & Firebase Setup Modal */}
      <ConfigGuideModal
        isOpen={isConfigGuideOpen}
        onClose={() => setIsConfigGuideOpen(false)}
      />

      {/* Toast Notifications */}
      <ToastContainer toasts={toasts} onDismiss={removeToast} />
    </div>
  );
}
