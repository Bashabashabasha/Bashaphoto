# ba. sha_as - Personal Media Gallery ("memories with friends")

A clean, production-ready personal photo and video gallery website built with React, Vite, and Tailwind CSS.

## Features
- **100% Original Quality**: Zero compression, downscaling, or transcoding. Exact original bytes preserved.
- **Direct Downloads**: Direct "Download Original" button for each file and "Download Selected" uncompressed ZIP archive.
- **Admin Password Gate**: Read from `VITE_ADMIN_PASSWORD` (default: `hinata`). Required for Upload and Delete operations; browsing and downloading require no password.
- **Resilient Cloud & Local Storage**: Integrates with Firebase Storage & Cloud Firestore, with graceful fallback for seamless preview.
- **Fullscreen Lightbox**: Mobile touch swipe gestures, keyboard arrows/escape, and video player with full controls.
- **Vercel Ready**: Pre-configured with `vercel.json` for immediate zero-config deployment.

---

## 1. How to Push to GitHub

Run these commands in your project terminal:

```bash
# Initialize git and stage all project files
git init
git add .
git commit -m "feat: complete personal media gallery ready for Vercel"
git branch -M main

# Link to your GitHub repository (replace with your repo URL)
git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPOSITORY.git

# Push to your GitHub repository
git push -u origin main
```

---

## 2. Deploying on Vercel

1. Log in to [vercel.com](https://vercel.com) and click **"Add New Project"**.
2. Select your imported GitHub repository.
3. Framework Preset will automatically detect **Vite**.
4. In the **Environment Variables** section, add:

| Key | Description | Example / Default |
|-----|-------------|-------------------|
| `VITE_ADMIN_PASSWORD` | Owner password for uploads & deletions | `hinata` |
| `VITE_FIREBASE_API_KEY` | Firebase Web API key | `AIzaSy...` |
| `VITE_FIREBASE_AUTH_DOMAIN` | Firebase Auth Domain | `my-app.firebaseapp.com` |
| `VITE_FIREBASE_PROJECT_ID` | Firebase Project ID | `my-app` |
| `VITE_FIREBASE_STORAGE_BUCKET` | Firebase Storage Bucket | `my-app.appspot.com` |
| `VITE_FIREBASE_MESSAGING_SENDER_ID` | Sender ID | `1234567890` |
| `VITE_FIREBASE_APP_ID` | App ID | `1:1234567890:web:abcdef` |

5. Click **Deploy**. Your gallery will be live with full SPA routing!

---

## 3. Firebase Security Rules

To allow friends to browse and download original files while safeguarding uploads/deletions with your admin password:

### Firestore Rules (`firestore.rules`)
```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /gallery_media/{document=**} {
      // Anyone can browse and view metadata
      allow read: if true;
      // Protected by admin password in the app
      allow write: if true;
    }
  }
}
```

### Firebase Storage Rules (`storage.rules`)
```javascript
rules_version = '2';
service firebase.storage {
  match /b/{bucket}/o {
    match /gallery/{allPaths=**} {
      // Anyone can read and download exact original quality files
      allow read: if true;
      // Protected by admin password in the app
      allow write: if true;
    }
  }
}
```
